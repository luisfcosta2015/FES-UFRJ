package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectionFactory {
	private static final String Driver = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/fes";
	private static final String USER = "root";
	private static final String PASS = "";
	
	public static Connection getConnection() {
		try {
			Class.forName(Driver);
			
			return DriverManager.getConnection(URL, USER, PASS);
			
		} catch (ClassNotFoundException | SQLException e) {
			throw new RuntimeException("Erro Connection",e);
		}
		
	};
	
	public static void closeConnection(Connection con) {
		try {
			con.close();
		} catch (SQLException e) {
			System.err.println("Erro: "+e);
		}
	}
	
	public static void closeConnection(Connection con, PreparedStatement ext) {
		try {
			ext.close();
		} catch (SQLException e) {
			System.err.println("Erro: "+e);
		}
		closeConnection(con);
	}
	public static void closeConnection(Connection con, PreparedStatement ext, ResultSet re) {
		try {
			re.close();
		} catch (SQLException e) {
			System.err.println("Erro: "+e);
		}
		closeConnection(con,ext);
	}
}
